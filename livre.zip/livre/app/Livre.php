<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Livre extends Model
{
    protected $table = "livre";


  public static function getNbLivres(){

      return DB::table('livre')
          ->select(DB::raw('COUNT(*) as nb'))
          ->first();
  }


}
