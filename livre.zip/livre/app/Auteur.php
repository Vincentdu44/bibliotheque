<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class auteur extends Model
{
  protected $table = "auteur";

  public static function getNbAuteurs(){

      return DB::table('auteur')
          ->select(DB::raw('COUNT(*) as nb'))
          ->first();
  }

  public static function getNbAuteursByCourant(){
    return Auteur::select(DB::raw('COUNT(auteur.id) as value'))
    ->groupBy('courant_literaire')
    ->get();

}

}
