<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/','WelcomeController@welcome')->name('homepage');

Route::get('/stats','WelcomeController@stats')->name('stats');

Route::any('/livres/liste','LivreController@lister')->name('livres.liste');

Route::any('/numerique/{id}/{numerique}', 'LivreController@numerique')->name('numerique');

Route::any('/supprimer/{id}', 'LivreController@supprimer')->name('supprimer');

Route::any('/pdf/{id}', 'LivreController@render')->name('pdf');

Route::any('/voir/{id}', 'LivreController@voir')->name('voir');

Route::any('/panier/{id}/{action}', 'LivreController@panier')->name('panier');

Route::any('/formulaire', 'LivreController@formulaire')->name('formulaire');

Route::any('/auteurs/liste','AuteurController@lister')->name('auteurs.liste');

Route::any('/formulaire_auteur', 'AuteurController@formulaire')->name('formulaire_auteur');

Route::any('/voirAuteur/{id}', 'AuteurController@voir')->name('voirAuteur');

Route::any('/supprimerAuteur/{id}', 'AuteurController@supprimer')->name('supprimerAuteur');
