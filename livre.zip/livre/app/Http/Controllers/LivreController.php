<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Livre;

use App;

use Illuminate\Support\Facades\DB;

use \Session;

use Validator;


class LivreController extends Controller
{

    public function lister(){

      $livres = Livre::all();//récupérer tous les livres


    return view('ListLivre',[
      'livres' => $livres]);
    }


    public function numerique(Livre $id)
 {
     $id->version_num = !$id->version_num;
     $id->save();

     return redirect()->route('livres.liste')
         ->with('success', "La version numérique du livre a bien été modifiée.");
 }


    public function supprimer(Livre $id){
        $id->delete();

        $livres = Livre::all();//récupérer tous les livres
    return redirect()->route('livres.liste')->with('success', 'livre supprimé');

    }


    public function voir($id){

      $livre = Livre::select('livre.id', 'livre.titre', 'livre.prix', 'livre.numero_isbn', 'livre.image', 'livre.numero_ean', 'livre.maison_edition', 'livre.date_parution', 'livre.magasin', 'livre.version_num', 'livre.vues','auteur.nom as nom', 'auteur.prenom as prenom')->join('auteur', 'auteur.id','=','livre.id_auteur')->where('livre.id','=', $id)->first();

      return view('voir',[
        'livre' => $livre]);
    }



  public function render(Livre $id){
    $pdf = App::make('dompdf.wrapper');
    $pdf->loadHTML(
    "<h1>".$id->titre."</h1>".
    "<img src='".$id->image."' width='250px'/>".
    "<p>".$id->resume."</p>");
    return $pdf->stream();

  }

  public function panier(Livre $id, $action) {
      $likes = session('likes', []);

      if ($action == 'like') {
          $likes[$id->id] = $id->titre;
          $message = "Le livre {$id->titre} a bien été liké";
      } else {
          unset($likes[$id->id]);
          $message = "Le livre {$id->titre} a bien été disliké";
      }

      session()->put('likes', $likes);

      return back()->with('success', $message);
   }



public function formulaire(Request $request){


  $validator = Validator::make($request->all(), [
      'titre'=>'required|min:3|regex:/^[A-Za-z0-9\s]+$/|unique:livre,titre',
      'prix'=>'required|numeric',
      'numero_isbn'=>'required|numeric|min:10',
      'image'=>'required|active_url',
      'maison_edition'=>'required',
      'date_parution'=>'required|date_format:d/m/Y',
      'cg'=>'required',
    ],[
      'required'=>'Le champs :attribute est obligatoire',
      'titre.regex' => "Le titre n'est pas valide",
      'titre.min' => '3 caractères'
  ]);

  if ($validator->fails() && $request->isMethod('post')){

  return redirect()->route('formulaire')
    ->withErrors($validator) //avec erreurs
    ->withInput(); //avec champs remplis

  }
  else if ($request->isMethod('post')){


      //créer un nouveau en bdd
      $dateformat =  \DateTime::createFromFormat('d/m/Y', $request->date_parution);
      $livre = new Livre();
      $livre->titre = $request->titre;
      $livre->prix = $request->prix;
      $livre->numero_isbn = $request->numero_isbn;
      $livre->image = $request->image;
      $livre->maison_edition = $request->maison_edition;
      $livre->date_parution = $dateformat;
      $livre->save();

      //redirection pour le succes avec message
    return redirect()->route('formulaire') //redirige vers
      ->with('success', 'votre nouveau livre a été enregistré');
  }



  //controller les données de mon formulaire
    return view('formulaire');
}



}
