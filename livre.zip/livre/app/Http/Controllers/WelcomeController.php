<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Livre;

use App\Auteur;


class WelcomeController extends Controller
{

  // retourner un JSON (tableau d'objets en JS)
  public function stats(){
      $nbCourant = Auteur::getNbAuteursByCourant();

      foreach($nbCourant as $key => $courant_literaire){
          //caseter une chaine en nombre
          $nbCourant[$key]['value'] = (int) $nbCourant[$key]['value'];
      }
      return $nbCourant->tojson();

    }

  public function welcome(){
    $nbLivres = Livre::getNbLivres();

    $nbAuteurs = Auteur::getNbAuteurs();

    $livre = Livre::all()->random();//récupérer tous les livres au hasard

    $auteur = Auteur::all()->random();

      return view('welcome',
      [
          'auteur' => $auteur,
          'livre' => $livre,
          'nbLivres' => $nbLivres,
          'nbAuteurs' => $nbAuteurs,

      ]);
    }

}
