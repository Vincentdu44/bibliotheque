<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Auteur;

use App;

use Illuminate\Support\Facades\DB;

use \Session;

use Validator;

use PDF;

class AuteurController extends Controller
{
  public function lister(){

    $auteurs = Auteur::all();//récupérer tous les livres

    return view('ListAuteur',[
      'auteurs' => $auteurs ]);

  }

  public function supprimer(Auteur $id){
      $id->delete();

      $auteurs = Auteur::all();//récupérer tous les livres
          return redirect()->route('auteurs.liste')->with('success', 'auteur supprimé');

  }


  public function voir($id){

    $auteurs = Auteur::all();

    foreach ($auteurs as $auteur) {
      if ($auteur->id == $id){
                 return view('voirAuteur',[
                   'auteur' => $auteur
                 ]);
             }
         };

  }


public function formulaire(Request $request){


$validator = Validator::make($request->all(), [
    'nom'=>'required',
    'prenom'=>'required',
    'image'=>'required|active_url',
    'ville'=>'required',
    'courant_literaire'=>'required',
    'date_birth'=>'required|date_format:d/m/Y',
    'bio'=>'required|min:5|max:400',
    'sexe'=>'required|in:homme,femme',
  ],[
    'required'=>'Le champs :attribute est obligatoire',
    'bio.min' => '5 caractères mini'
]);

if ($validator->fails() && $request->isMethod('post')){

    return redirect()->route('formulaire_auteur')
    ->withErrors($validator) //avec erreurs
    ->withInput(); //avec champs remplis

}
else if ($request->isMethod('post')){


    //créer un nouveau en bdd
    $dateformat =  \DateTime::createFromFormat('d/m/Y', $request->date_birth);
    $auteur = new Auteur();
    $auteur->sexe = $request->sexe;
    $auteur->nom = $request->nom;
    $auteur->prenom = $request->prenom;
    $auteur->image = $request->image;
    $auteur->ville = $request->ville;
    $auteur->courant_literaire = $request->courant_literaire;
    $auteur->date_birth = $dateformat;
    $auteur->bio = $request->bio;
    $auteur->save();

    //redirection pour le succes avec message
    return redirect()->route('formulaire_auteur') //redirige vers
      ->with('success', 'votre nouvel auteur a été enregistré');
}



//controller les données de mon formulaire
  return view('formulaire_auteur');
}
}
