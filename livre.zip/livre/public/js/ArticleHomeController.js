
app.controller('ArticleHomeController', function ArticleHomeController($scope, $http, $interval) {

// $http: permet d'interroger une URL et de retourner les données en JSON
// $interval: permet d'executer une fonction à travers un interval de temps

  $scope.comments = [];

  // je charge mes données en JSON avec le module $http

  function areDiffrentByIds(a,b){
    var idsA = a.map( function(x){ return x.id; } ).sort();
    var idsB = b.map( function(x){ return x.id; } ).sort();
    return (idsA.join(',') !== idsB.join(',') );
  }

  $interval(function(){
    console.log($scope.take);
    $http.get('articlehome/' + $scope.skipe + "/" + $scope.take)
    .then(function(response) {
      if(areDiffrentByIds($scope.comments,response.data)){
        $scope.comments = response.data;
      }
    });
  }, 1000);


$scope.skipe = 0;
$scope.take = 5;

$scope.voirPlus = function(){

    $scope.take += 300;//augmenter le take de 300

};

  $scope.add = function(){

    if($scope.content.length >0){
//http post me permet de faire une REQUETE en post
      $http.post('/articlehome', //url (uri)
      {'content' : $scope.content.trim()})
// content : name de mon input
//$scope.content : valeur de mon input
      //envoi de données

      .then(function(response) {
        $scope.content = '';
      });
    }
  };

});
