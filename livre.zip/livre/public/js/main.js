//quand le document est prêt
$(document).ready(function() {

//je selectionne le button
//je greffe l'évènement click sur mon élément button
$('#vert').click(function(){
  //je modifie la css de mon html sélectionné
  //.css()
  $('h1,h2,h3,thead,.info-box-text').css("color","green");
  });

  $('#rouge').click(function(){
    $('h1,h2,h3,thead,.info-box-text').css("color","red");
    });
//bouton +
$("#plus").click(function(){
  $('.content-wrapper,.info-box-number,table').css("font-size","2em");
  });

// bouton -
$("#moins").click(function(){
  $('.content-wrapper,.info-box-number,table').css("font-size","0.5em");
  });

// bouton =
$("#egal").click(function(){
  $('.content-wrapper,.info-box-number,table').css("font-size","1em");
  });

// bouton gras
$("#gras").click(function(){
  $('.content-wrapper,table').css("font-weight","bold");
  });

// saisie texte en dessous
$("#compteurUn").keyup(function() {
   compter($("#compteurUn"),$("#compteurBio"));
  });

$("#compteurDeux").keyup(function() {
   compter($("#compteurDeux"),$("#compteurTitre"));
  });

$("#compteurTrois").keyup(function() {
   compter($("#compteurTrois"),$("#compteurIsbn"));
  });

  function compter(src,dest){
    var txtVal = src.val();
    var mots = txtVal.trim().replace(/\s+/gi, ' ').split(' ').length;
    var caracteres = txtVal.length;
    if(caracteres===0){
      mots=0;
    }
    dest.html(mots+"mots"+ caracteres +"caractères");
  }

//liste déroulante
$("select").change(function(){
  $("select option:selected").click(function(){
  var police = $(this).text();
  $('.content-wrapper').css("font-family",police);

  });
  });

//champs qui baisse ou augmente opacité
//
$("#range").click(function(){
  console.log($("#range").val());
  var valRange = $("#range").val()/100;
  $ (".content-wrapper").css("opacity",valRange);
});

});
